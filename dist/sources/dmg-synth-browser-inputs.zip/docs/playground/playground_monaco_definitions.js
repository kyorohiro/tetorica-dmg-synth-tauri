/** Read-only definition/source viewer. Library files never enter the project or cassette. */
const nativeFetch = globalThis.fetch?.bind(globalThis);

export function definitionSource(text, position, chip = 'ym2612', options = {}) {
  const lines = text.split('\n');
  const line = lines[position?.startLineNumber ? position.startLineNumber - 1 : (position?.lineNumber ?? 1) - 1] ?? '';
  const column = position?.startColumn ?? position?.column ?? 1;
  const symbol = /[\w$]+/.exec(line.slice(column - 1))?.[0] ?? '';
  const prefix = lines.slice(0, position?.startLineNumber ?? position?.lineNumber ?? 1).join('\n');
  const owners = [...prefix.matchAll(/^(?:declare\s+)?(?:interface|type)\s+(\w+)/gm)];
  const owner = owners.at(-1)?.[1] ?? '';
  if (symbol === 'assembleScspDsp' || symbol === 'disassembleScspDsp')
    return {file:'scsp_dsp_assembler.js',symbol};
  // Member names such as play/stop belong to their declared media interface,
  // before similarly named global music helpers are considered.
  if(owner==='SnesCodeClient'&&['noteOn','noteOff','getState','allNotesOff','dispose'].includes(symbol))
    return {file:'synth-snes/code_client.js',symbol};
  if(owner==='NesCodeClient'&&['noteOn','keyOn','getState','allNotesOff','dispose'].includes(symbol))
    return {file:'synth-2a03/code_endpoint.js',symbol:'createNesCodeClient'};
  if(owner==='AswanCodeClient'&&['getState','noteOff','dispose'].includes(symbol))
    return {file:'synth-aswan/code_endpoint.js',symbol:'createAswanCodeClient'};
  if(owner==='ScspCodeClient')
    return {file:'synth-scsp/code_endpoint.js',symbol:'createScspCodeClient'};
  if(owner==='Fm2608CodeClient') {
    if(['setTimerA','setCsm','setChannel3Mode','getChannel3State'].includes(symbol))
      return {file:'synth-fm2608/sound_state.js',symbol:symbol==='setCsm'?'installChannel3Controls':symbol};
    if(symbol==='capturePreset')return {file:'synth-fm2608/audio.js',symbol};
    if(['allNotesOff','dispose'].includes(symbol))return {file:'synth-fm2608/code_client.js',symbol};
    if(['ssg','rhythm','adpcm'].includes(symbol))return {file:'ym2608synth.js',symbol:'YM2608Synth'};
    const declaration=prefix.slice(owners.at(-1).index);
    const section=[...declaration.matchAll(/^\s*(ssg|rhythm|adpcm)\s*:\s*\{/gm)].at(-1)?.[1];
    if(section==='ssg')return {file:'ssgsynth.js',symbol:'SSGSynth.'+symbol};
    if(section==='rhythm')return {file:'ym2608synth.js',symbol:'YM2608RhythmSynth.'+symbol};
    if(section==='adpcm')return {file:'ym2608synth.js',symbol:'YM2608AdpcmSynth.'+symbol};
    if(['keyOff','setModulation'].includes(symbol))return {file:'opn_fm_synth.js',symbol};
    return {file:'ym2608synth.js',symbol:'YM2608Synth'};
  }
  if(owner==='PlaygroundMsm5205API')return {file:'msm5205_player.js',symbol};
  if(owner==='PlaygroundCddaAPI')return {file:'cdda_player.js',symbol};
  if(/^Huc6280Code(?:Msm5205|Cdda)$/.test(owner)&&symbol==='dispose')return {file:'synth-huc6280/cdrom2_audio.js',symbol:'createHuc6280Cdrom2Audio'};
  if(options.runtimeFile) {
    const runtime=['useSoundChip','setBpm','beat','nextBeat','sleep','sleepSamples','tween','liveLoop','livePrepare','liveFx',
      'stopLoop','stopAllLoops','liveCleanup','trackAsync','file','log','console'];
    if(runtime.includes(symbol))return {file:options.runtimeFile,symbol};
    if(['context','pg','fm'].includes(symbol)||/^(?:CH[1-6]|PSG[1-3]|OP[1-4])$/.test(symbol))return {file:options.runtimeFile,symbol:'createPlaygroundCodeRuntime'};
    if(symbol==='FM_PRESETS')return {file:'megasynth-fm-presets.js',symbol};
    if(symbol==='cycle')return {file:'playground_music.js',symbol:'createCycle'};
    if(['parseNoteName','toPitch','midiToNoteName','lerp','choose','rand','rrange','randInt'].includes(symbol))return {file:'playground_music.js',symbol};
    if(symbol==='hzToBlockFnum')return {file:'soundchip_pitch.js',symbol:'opnPitchFromHz'};
  }
  if (symbol === 'sid') return {file:'playground_sid.js',symbol:'createSidClient'};
  if (/^Playground(?:Primary)?Sid$/.test(owner) && ['readRegister','getState','setClock'].includes(symbol)) return {file:'playground_sid.js',symbol:'createSidRegisterClient'};
  if (/^Playground(?:Primary)?Sid/.test(owner)) return {file:'sidsynth.js',symbol:/^Playground/.test(symbol)?'SidSynth':symbol};
  if (symbol === 'opl') return {file:'playground_opl.js',symbol:'createOplClient'};
  if (symbol === 'encodeBrr') return {file:'snes_brr_encoder.js',symbol};
  if (symbol === 'encodeAdpcmA') return {file:'adpcm_a_sample.js',symbol};
  if (symbol === 'encodePs1Adpcm') return {file:'ps1_adpcm_encoder.js',symbol};
  if (['readVab','prepareVabTone','exportVab','MAX_VAB_FILE_BYTES'].includes(symbol)) return {file:'ps1_vab.js',symbol};
  if (/^Ps1Vab(?:Bank|Program|Tone|Sample|PreparedTone|ExportOptions)$/.test(symbol)) return {file:'ps1_vab.js',symbol};
  if (/^Ps1Vab(?:Bank|Program|Tone|Sample|PreparedTone|ExportOptions)$/.test(owner)) return {file:'ps1_vab.js',symbol:owner};
  if (symbol === 'OPL_PRESETS') return {file:'opl_synth.js',symbol:'OPL_PRESETS'};
  if (symbol === 'opll') return {file:'playground_ym2413.js',symbol:'createYm2413Client'};
  if (symbol === 'ay') return {file:'playground_ay8910.js',symbol:'createAy8910Client'};
  if (symbol === 'OPLL_INSTRUMENTS') return {file:'ym2413synth.js',symbol:'YM2413_INSTRUMENTS'};
  if (symbol === 'OPLL_USER_PRESETS') return {file:'ym2413synth.js',symbol:'YM2413_USER_PRESETS'};
  if (['YM2413_INSTRUMENTS','YM2413_USER_PRESETS'].includes(symbol)) return {file:'ym2413synth.js',symbol};
  if (['useSoundChip', 'createSoundChip', 'setBpm', 'beat', 'nextBeat', 'sleep', 'sleepSamples', 'tween', 'createTimeline'].includes(symbol)) return {file:'playground_runtime.js', symbol};
  if (owner === 'PlaygroundSecondsTimeline') return {file:'playground_clock.js',symbol};
  if (['hzToBlockFnum', 'createPitchFromMidi'].includes(symbol)) return {file:'pitch.js', symbol};
  if (['noteToBlockFnum', 'play', 'scale', 'chord', 'noteLerp'].includes(symbol)) return {file:'playground_music.js', symbol};
  if(/^PlaygroundPs1Operation(?:Program|Recorder)$/.test(owner))return {file:'ps1_operations.js',symbol:'buildPs1Operations'};
  if(owner==='PlaygroundPs1StateSnapshot')return {file:'ps1_timed_state.js',symbol:'createPs1TimedSnapshot'};
  if(owner==='PlaygroundPs1CompiledWrite')return {file:'ps1_operations.js',symbol:'compilePs1Operations'};
  if(['PlaygroundPs1','PlaygroundPrimaryPs1','SpuCodeClient'].includes(owner)&&['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
    return symbol==='build'?{file:'ps1_operations.js',symbol:'buildPs1Operations'}:{file:'ps1_timed_client.js',symbol:'attachPs1TimedClient'};
  if (/^Playground(?:Primary)?Ps1/.test(owner)||owner==='SpuCodeClient') return {file:'ps1synth.js',symbol:/^(?:Playground|SpuCodeClient)/.test(symbol)?'Ps1Synth':symbol};
  if (/^Playground(?:Primary)?Scsp/.test(owner)) return {file:'scspsynth.js',symbol:owner==='PlaygroundScsp'&&!/^Playground/.test(symbol)?'ScspSynth.'+symbol:'ScspSynth'};
  if (/^PlaygroundNes$/.test(owner)) return {file:'nesapusynth.js', symbol};
  if(/^PlaygroundGameboy(?:OperationRecorder|OperationProgram|RecordedOperation)$/.test(owner))return {file:'gameboy_operations.js',symbol:'buildGameboyOperations'};
  if(/^PlaygroundGameboy(?:StateSnapshot|OperationState)$/.test(owner))return {file:'gameboy_timed_state.js',symbol:'createGameboyTimedSnapshot'};
  if(owner==='PlaygroundGameboyCompiledWrite')return {file:'gameboy_operations.js',symbol:'compileGameboyOperations'};
  if(/^PlaygroundGameboy(?:CompileOptions|ScheduleOptions|ScheduleReceipt)$/.test(owner)||
      ['PlaygroundGameboy','PlaygroundPrimaryGameboy','GameboyCodeClient'].includes(owner)&&['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
    return symbol==='build'?{file:'gameboy_operations.js',symbol:'buildGameboyOperations'}:{file:'gameboy_timed_client.js',symbol:'attachGameboyTimedClient'};
  if (/^Playground(?:Primary)?Gameboy$/.test(owner)) return {file:'gameboysynth.js', symbol};
  if(owner==='PlaygroundWonderSwanOperationRecorder'||owner==='PlaygroundWonderSwanOperationProgram')return {file:'wonderswan_operations.js',symbol:'buildWonderSwanOperations'};
  if(owner==='PlaygroundWonderSwanStateSnapshot')return {file:'wonderswan_timed_state.js',symbol:'createWonderSwanTimedSnapshot'};
  if(owner==='PlaygroundWonderSwanCompiledWrite')return {file:'wonderswan_operations.js',symbol:'compileWonderSwanOperations'};
  if(['PlaygroundWonderSwan','PlaygroundPrimaryWonderSwan'].includes(owner)&&['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
    return symbol==='build'?{file:'wonderswan_operations.js',symbol:'buildWonderSwanOperations'}:{file:'wonderswan_timed_client.js',symbol:'attachWonderSwanTimedClient'};
  if (/^Playground(?:Primary)?WonderSwan(?:TimelineBuilder)?$/.test(owner)) return {file:'wonderswansynth.js',symbol:/^Playground/.test(symbol)?'WonderSwanSynth':symbol};
  if(/^PlaygroundHuc6280(?:OperationRecorder|RecordedMethod|OperationTime|RecordedOperation|OperationProgram)$/.test(owner))
    return {file:'huc6280_operations.js',symbol:'buildHuc6280Operations'};
  if(owner==='PlaygroundHuc6280StateSnapshot'||owner==='PlaygroundHuc6280OperationState')return {file:'huc6280_timed_state.js',symbol:'createHuc6280TimedSnapshot'};
  if(owner==='PlaygroundHuc6280CompiledWrite')return {file:'huc6280_operations.js',symbol:'compileHuc6280Operations'};
  if(/^PlaygroundHuc6280(?:CompileOptions|ScheduleOptions|ScheduleReceipt)$/.test(owner)||
      ['PlaygroundHuc6280','PlaygroundPrimaryHuc6280','Huc6280CodeClient'].includes(owner)&&['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
    return symbol==='build'?{file:'huc6280_operations.js',symbol:'buildHuc6280Operations'}:{file:'huc6280_timed_client.js',symbol:'attachHuc6280TimedClient'};
  if(owner==='Huc6280CodeClient'&&['getState','noteOn','noteOff','dispose'].includes(symbol))
    return {file:'synth-huc6280/instrument.js',symbol:{getState:'observeCode',noteOn:'_liveNoteOn',noteOff:'noteOff',dispose:'stop'}[symbol]};
  if(/^Playground(?:Primary)?Huc6280/.test(owner)||owner==='Huc6280CodeClient')
    return {file:'huc6280synth.js',symbol:/^(?:Playground|Huc6280CodeClient)/.test(symbol)?'Huc6280Synth':symbol};
  if (/^PlaygroundYm2151$/.test(owner)) return {file:'playground_ym2151.js', symbol};
  if (/^PlaygroundDx7$/.test(owner)) return {file:'playground_dx7.js', symbol};
  if (/^PlaygroundSnes$/.test(owner)) return {file:'playground_snes.js', symbol};
  if (/^PlaygroundSpc$/.test(owner)) return {file:'playground_spc.js', symbol};
  if (/^PlaygroundYm2608$/.test(owner)) return {file:'ym2608synth.js', symbol};
  if (/^PlaygroundRf5c164$/.test(owner)) return {file:'rf5c164synth.js', symbol};
  for (const [prefix, file, build, compile, snapshot, attach, aliases] of [
    ['PlaygroundSegaPsg', 'segapsg', 'buildPsgOperations', 'compilePsgOperations', 'createPsgTimedSnapshot', 'attachPsgTimedClient', ['SmsGearPsg']],
    ['PlaygroundYm2413', 'ym2413', 'buildOpllOperations', 'compileOpllOperations', 'createOpllTimedSnapshot', 'attachOpllTimedClient', ['PlaygroundPrimaryYm2413', 'SmsGearOpll']],
  ]) {
    if (owner === prefix + 'OperationProgram' || owner === prefix + 'OperationRecorder' || owner === prefix + 'BuildOptions')
      return {file:file + '_operations.js', symbol:build};
    if (owner === prefix + 'StateSnapshot') return {file:file + '_timed_state.js', symbol:snapshot};
    if (owner === prefix + 'CompiledWrite') return {file:file + '_operations.js', symbol:compile};
    if (owner === prefix + 'TimedApi' || [prefix, ...aliases].includes(owner) && ['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
      return symbol === 'build' ? {file:file + '_operations.js', symbol:build} : {file:file + '_timed_client.js', symbol:attach};
  }
  if (/^(?:PlaygroundSegaPsg|PSGApi)$/.test(owner)) return {file:'segapsgsynth.js', symbol};
  if (/^Playground(?:Primary)?(?:Opll|Ym2413)/.test(owner)) return {file:'ym2413synth.js',symbol:/^Playground/.test(symbol) ? 'YM2413Synth' : symbol};
  if (owner === 'PlaygroundYm2612OperationRecorder' || /^PlaygroundYm2612(?:BuildOptions|OperationProgram)$/.test(owner))
    return {file:'ym2612_operations.js',symbol:'buildYm2612Operations'};
  if (owner === 'PlaygroundYm2612StateSnapshot') return {file:'ym2612_timed_state.js',symbol:'createYm2612TimedSnapshot'};
  if (owner === 'PlaygroundYm2612CompiledWrite') return {file:'ym2612_operations.js',symbol:'compileYm2612Operations'};
  if (/^PlaygroundYm2612(?:TimedApi|CompileOptions|ScheduleOptions|ScheduleReceipt)$/.test(owner) ||
      ['YM2612FMApi','PlaygroundCreatedFm','SynthCodeFm'].includes(owner) && ['build','compile','captureState','schedule','clearSchedule'].includes(symbol))
    return symbol === 'build' ? {file:'ym2612_operations.js',symbol:'buildYm2612Operations'} : {file:'ym2612_timed_client.js',symbol:'attachYm2612TimedClient'};
  if (owner === 'PlaygroundAy8910OperationRecorder' ||
      /^PlaygroundAy8910(?:BuildOptions|RecordedMethod|OperationTime|RecordedOperation|OperationProgram)$/.test(owner)) {
    return {file:'ay8910_operations.js',symbol:'buildAyOperations'};
  }
  if (owner === 'PlaygroundAy8910StateSnapshot') return {file:'ay8910_timed_state.js',symbol:'createAyTimedSnapshot'};
  if (owner === 'PlaygroundAy8910CompiledWrite') return {file:'ay8910_operations.js',symbol:'compileAyOperations'};
  if (/^PlaygroundAy8910(?:CompileOptions|ScheduleOptions|ScheduleReceipt)$/.test(owner))
    return {file:'ay8910_timed_client.js',symbol:'attachAyTimedClient'};
  if ((/^Playground(?:Primary)?Ay8910$/.test(owner) || owner === 'YmCodeClient') &&
      ['build','compile','captureState','schedule','clearSchedule'].includes(symbol)) {
    return symbol === 'build' ? {file:'ay8910_operations.js',symbol:'buildAyOperations'} :
      {file:'ay8910_timed_client.js',symbol:'attachAyTimedClient'};
  }
  if (/^Playground(?:Primary)?(?:Ay8910|AY8910)/.test(owner)) return {file:'ay8910synth.js',symbol:/^Playground/.test(symbol) ? 'AY8910Synth' : symbol};
  if (/^Playground(?:Primary)?Opl/.test(owner)) return {file:'opl_synth.js',symbol:/^Playground(?:Primary)?Opl/.test(symbol) ? 'OPLSynth' : symbol};
  if (/^PlaygroundPWM32X$/.test(owner)) return {file:'pwm32x_playback.js', symbol};
  if (['FMApi','PlaygroundOPNFm','PlaygroundCreatedFm','PlaygroundCreatedYm2203','PlaygroundCreatedYm2610'].includes(owner)) {
    return {file:chip === 'ym2612' ? 'ym2612synth.js' : 'opn_fm_synth.js', symbol};
  }
  return null;
}

export function sourcePosition(text, symbol) {
  const qualified=/^([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)$/.exec(symbol);
  if(qualified) {
    const [,className,method]=qualified;
    const start=new RegExp(`^(?:export\\s+)?class\\s+${className}\\b`,'m').exec(text);
    if(!start)return {lineNumber:1,column:1};
    const remainder=text.slice(start.index),next=/\n(?:export\s+)?class\s/.exec(remainder);
    const body=next?remainder.slice(0,next.index):remainder;
    const point=sourcePosition(body,method);
    return {lineNumber:text.slice(0,start.index).split('\n').length+point.lineNumber-1,column:point.column};
  }
  const escaped = symbol.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`^\\s*(?:(?:export\\s+)?(?:default\\s+)?(?:(?:async\\s+)?function\\s+|(?:const|let|var|class)\\s+))?(?:async\\s+)?${escaped}\\s*(?:\\(|:|=|\\{)`, 'm');
  // Small runtime facades may put several object methods on one line. Match
  // an actual method body after a separator, never a member call site.
  const match = pattern.exec(text)??new RegExp(`[},;]\\s*(?:async\\s+)?${escaped}\\s*(?:\\([^)]*\\)\\s*\\{|:\\s*(?:async\\s*)?\\([^)]*\\)\\s*=>)`,'m').exec(text);
  if (!match) {
    // Public pure helpers expose structured types with JSDoc rather than a
    // JavaScript class. Keep implementation navigation on their real typedef.
    const typedef=new RegExp(`@typedef\\s+\\{[^\\n]*\\}\\s+${escaped}\\b`).exec(text);
    if(!typedef)return {lineNumber:1,column:1};
    const index=typedef.index+typedef[0].lastIndexOf(symbol),prefix=text.slice(0,index);
    return {lineNumber:prefix.split('\n').length,column:index-prefix.lastIndexOf('\n')};
  }
  const index = match.index + match[0].indexOf(symbol);
  const prefix = text.slice(0,index);
  return {lineNumber:prefix.split('\n').length, column:index - prefix.lastIndexOf('\n')};
}

/** Native API basenames live in js/. Namespaced application implementations
 * retain their authored layout, so relative source imports remain navigable. */
export function runtimeSourceUrl(file,base=import.meta.url) {
  if(typeof file!=='string'||!file.endsWith('.js')||!file.split('/').every(part=>/^[\w.-]+$/.test(part)&&part!=='.'&&part!=='..'))throw new TypeError('Invalid implementation source path');
  return new URL(file.includes('/')?`../${file}`:`../js/${file}`,base);
}

/** Locate the module needed to resolve an imported identifier without loading the whole runtime. */
export function runtimeImport(text, symbol) {
  const imports=/^\s*import\s+([\w$\s{},*]+?)\s+from\s*['"]([^'"]+)['"]/gm;
  for(const match of text.matchAll(imports)){
    const [,bindings,specifier]=match;
    if(!specifier.startsWith('./')&&!specifier.startsWith('../'))continue;
    const named=/\{([^}]+)\}/.exec(bindings)?.[1];
    for(const entry of (named??'').split(',')){
      const [imported,local=imported]=entry.trim().split(/\s+as\s+/);
      if(local===symbol)return {specifier,symbol:imported};
    }
    const defaultName=/^\s*([\w$]+)/.exec(bindings)?.[1];
    if(defaultName===symbol)return {specifier,symbol:'default'};
  }
  return null;
}

export function sourceChip(editor, fallback) {
  const model=editor.getModel(), position=editor.getPosition();
  if(!model||!position)return fallback;
  const prefix=model.getLineContent(position.lineNumber).slice(0,position.column-1);
  const variable=/([\w$]+)\.\w*$/.exec(prefix)?.[1];
  if(!variable)return fallback;
  const escaped=variable.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const matches=[...model.getValue().matchAll(new RegExp(`\\b(?:const|let|var)\\s+${escaped}\\s*=\\s*await\\s+(?:pg\\.)?(?:useSoundChip|createSoundChip)\\(\\s*['"]([^'"]+)['"]`,'g'))];
  return matches.at(-1)?.[1]??fallback;
}

/** Index runtime globals independently of the language worker's lazy synchronization. */
export function globalDefinition(model, position, libraryModels) {
  const word=model.getWordAtPosition(position);
  if(!word)return null;
  const prefix=model.getLineContent(position.lineNumber).slice(0,word.startColumn-1);
  // Only a bare global or pg.helper is a Playground helper, not an arbitrary member.
  if(/\.\s*$/.test(prefix)&&!/(?:^|[^\w$.])pg\.\s*$/.test(prefix))return null;
  const escaped=word.word.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  for(const library of libraryModels.values()){
    const match=new RegExp(`^declare (?:function|const) (${escaped})(?=[\\s(<:;])`,'m').exec(library.getValue());
    if(!match)continue;
    const offset=match.index+match[0].lastIndexOf(word.word);
    const start=library.getPositionAt(offset),end=library.getPositionAt(offset+word.word.length);
    return {uri:library.uri,range:{startLineNumber:start.lineNumber,startColumn:start.column,endLineNumber:end.lineNumber,endColumn:end.column}};
  }
  return null;
}

export function createDefinitionViewer(monaco, mainEditor, libraryModels, options = {}) {
  const dialog=document.createElement('dialog'); dialog.dataset.monacoDefinition='true';
  Object.assign(dialog.style,{width:'min(1100px, 94vw)',maxWidth:'94vw',padding:'16px',background:'#111827',color:'#e5e7eb',border:'1px solid #475569',borderRadius:'10px'});
  const header=document.createElement('div');Object.assign(header.style,{display:'flex',gap:'12px',alignItems:'center',marginBottom:'12px'});
  const title=document.createElement('strong');title.style.flex='1';
  const implementation=document.createElement('button');implementation.type='button';implementation.textContent='View implementation';
  const close=document.createElement('button');close.type='button';close.textContent='Close';
  const message=document.createElement('p');message.setAttribute('role','status');message.style.margin='0 0 8px';
  const host=document.createElement('div');host.style.height='min(65vh, 620px)';host.style.width='100%';
  header.append(title,implementation,close);dialog.append(header,message,host);document.body.append(dialog);
  let viewer=null, target=null, revision=0, ownerChip=options.chip??'ym2612', disposed=false;
  const contextMenu=document.createElement('div');contextMenu.setAttribute('role','menu');contextMenu.hidden=true;
  Object.assign(contextMenu.style,{position:'absolute',zIndex:'10',padding:'6px',background:'#1e293b',border:'1px solid #475569',borderRadius:'6px'});
  const goDefinition=document.createElement('button');goDefinition.type='button';goDefinition.textContent='Go to Definition';goDefinition.setAttribute('role','menuitem');
  contextMenu.append(goDefinition);dialog.append(contextMenu);
  goDefinition.addEventListener('mousedown',event=>event.preventDefault());
  goDefinition.addEventListener('click',()=>{contextMenu.hidden=true;viewer?.focus();viewer?.trigger('runtime-context-menu','editor.action.revealDefinition',{});});
  dialog.addEventListener('mousedown',event=>{if(!contextMenu.contains(event.target))contextMenu.hidden=true;});
  dialog.addEventListener('cancel',event=>{if(!contextMenu.hidden){event.preventDefault();contextMenu.hidden=true;viewer?.focus();}});
  const sources=new Map();
  const pendingSources=new Map();
  async function loadSource(uri){
    const existing=sources.get(uri.toString());
    if(existing)return existing;
    if(uri.scheme!=='file'||!uri.path.startsWith('/tetorica-runtime/')||!uri.path.endsWith('.js'))return null;
    const key=uri.toString();
    if(!pendingSources.has(key))pendingSources.set(key,(async()=>{
      const file=uri.path.slice('/tetorica-runtime/'.length);
      const response=await nativeFetch(runtimeSourceUrl(file),{cache:'no-cache'});
      if(!response.ok)throw new Error(`HTTP ${response.status}: ${file}`);
      const text=await response.text();
      if(disposed)return null;
      const model=monaco.editor.getModel(uri)??monaco.editor.createModel(text,'javascript',uri);
      sources.set(key,model);return model;
    })().finally(()=>pendingSources.delete(key)));
    return pendingSources.get(key);
  }
  // Avoid the built-in provider returning a stale, unresolved import alias in parallel.
  const runtimeDefinitions=monaco.languages.registerDefinitionProvider({language:'javascript',scheme:'file',pattern:'**/tetorica-runtime/**',exclusive:true},{
    async provideDefinition(model,position,token){
      if(!sources.has(model.uri.toString()))return null;
      const word=model.getWordAtPosition(position);
      if(!word)return null;
      const imported=runtimeImport(model.getValue(),word.word);
      try{
        // Query strings are cache versions, not part of the source model's identity.
        let importedModel=null;
        if(imported){
          const url=new URL(imported.specifier,model.uri.toString());url.search='';url.hash='';
          importedModel=await loadSource(monaco.Uri.parse(url.href));
          if(!importedModel)return null;
        }
        if(token.isCancellationRequested||disposed)return null;
        const getWorker=await monaco.languages.typescript.getJavaScriptWorker();
        const worker=await getWorker(...[model.uri,importedModel?.uri].filter(Boolean));
        const definitions=await worker.getDefinitionAtPosition(model.uri.toString(),model.getOffsetAt(position));
        if(token.isCancellationRequested||disposed)return null;
        const resolved=definitions?.flatMap(definition=>{
          const uri=monaco.Uri.parse(definition.fileName),target=monaco.editor.getModel(uri);
          if(!target)return [];
          // An unresolved import alias still points at its own import statement.
          if(definition.kind==='alias'&&uri.toString()===model.uri.toString())return [];
          const start=target.getPositionAt(definition.textSpan.start),end=target.getPositionAt(definition.textSpan.start+definition.textSpan.length);
          return [{uri,range:{startLineNumber:start.lineNumber,startColumn:start.column,endLineNumber:end.lineNumber,endColumn:end.column}}];
        });
        if(resolved?.length)return resolved;
        if(!importedModel)return null;
        const point=sourcePosition(importedModel.getValue(),imported.symbol);
        return {uri:importedModel.uri,range:{startLineNumber:point.lineNumber,startColumn:point.column,endLineNumber:point.lineNumber,endColumn:point.column}};
      }catch(error){if(!disposed&&!token.isCancellationRequested)message.textContent=`Could not load definition: ${error.message}`;return null;}
    },
  });
  const globals=monaco.languages.registerDefinitionProvider('javascript',{
    async provideDefinition(model,position,token){
      if(!model.uri.path.startsWith('/project/'))return null;
      const fallback=globalDefinition(model,position,libraryModels);
      if(!fallback)return null;
      try{
        const getWorker=await monaco.languages.typescript.getJavaScriptWorker();
        const worker=await getWorker(model.uri);
        const definitions=await worker.getDefinitionAtPosition(model.uri.toString(),model.getOffsetAt(position));
        if(token.isCancellationRequested)return null;
        // Respect local bindings; also explicitly expose known models when the built-in adapter misses them.
        if(definitions?.length)return definitions.flatMap(definition=>{
          const uri=monaco.Uri.parse(definition.fileName),target=monaco.editor.getModel(uri);
          if(!target)return [];
          const start=target.getPositionAt(definition.textSpan.start),end=target.getPositionAt(definition.textSpan.start+definition.textSpan.length);
          return [{uri,range:{startLineNumber:start.lineNumber,startColumn:start.column,endLineNumber:end.lineNumber,endColumn:end.column}}];
        });
      }catch{if(token.isCancellationRequested)return null;}
      return fallback;
    },
  });
  function show(model, position) {
    if(disposed)return;
    if(!dialog.open)dialog.showModal();
    if(!viewer){
      viewer=monaco.editor.create(host,{model,readOnly:true,domReadOnly:true,theme:'vs-dark',automaticLayout:true,minimap:{enabled:false},fontSize:13,scrollBeyondLastLine:false,renderValidationDecorations:'off',contextmenu:false,
        // This viewer changes models as soon as a definition is followed.
        // Monaco 0.52 leaves a rejected WordHighlighter Delayer promise when
        // that happens during its pending symbol highlight. Keep the source
        // viewer free of those background requests; navigation stays enabled.
        occurrencesHighlight:'off'});
      viewer.onContextMenu(event=>{
        event.event.preventDefault();
        if(event.target.position)viewer.setPosition(event.target.position);
        const rect=dialog.getBoundingClientRect(),mouse=event.event.browserEvent;
        contextMenu.style.left=Math.max(0,Math.min(rect.width-180,mouse.clientX-rect.left))+'px';
        contextMenu.style.top=Math.max(0,Math.min(rect.height-50,mouse.clientY-rect.top))+'px';
        contextMenu.hidden=false;
      });
    }
    else viewer.setModel(model);
    title.textContent=model.uri.path.split('/').at(-1)+' (read-only)';
    message.textContent='';contextMenu.hidden=true;
    if(model.uri.path.endsWith('.d.ts'))target=definitionSource(model.getValue(),position,ownerChip,{runtimeFile:options.runtimeFile});
    else target=null;
    implementation.hidden=!target;implementation.disabled=false;
    const point=position?.startLineNumber ? {lineNumber:position.startLineNumber,column:position.startColumn} : position??{lineNumber:1,column:1};
    viewer.setPosition(point);viewer.revealLineInCenter(point.lineNumber);viewer.focus();
  }
  const opener=monaco.editor.registerEditorOpener({
    async openCodeEditor(source,resource,position) {
      if(source!==mainEditor&&source!==viewer)return false;
      const model=libraryModels.get(resource.toString())??sources.get(resource.toString());
      if(model){ownerChip=sourceChip(source,ownerChip);revision++;show(model,position);return true;}
      if(resource.scheme==='file'&&resource.path.startsWith('/project/')&&options.openVirtualFile){
        options.openVirtualFile(resource.path.slice('/project'.length));
        if(position?.startLineNumber){mainEditor.setSelection(position);mainEditor.revealLineInCenter(position.startLineNumber);}
        else if(position){mainEditor.setPosition(position);mainEditor.revealLineInCenter(position.lineNumber);}
        if(dialog.open)dialog.close();mainEditor.focus();return true;
      }
      return false;
    },
  });
  implementation.addEventListener('click',async()=>{
    const selected=target, token=++revision;if(!selected)return;
    implementation.disabled=true;message.textContent='Loading implementation…';
    try{
      const uri=monaco.Uri.parse(`file:///tetorica-runtime/${selected.file}`);
      const model=await loadSource(uri);
      if(!model||disposed||token!==revision)return;
      show(model,sourcePosition(model.getValue(),selected.symbol));
    }catch(error){if(!disposed&&token===revision){message.textContent=`Could not load implementation: ${error.message}`;implementation.disabled=false;}}
  });
  close.addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{revision++;contextMenu.hidden=true;mainEditor.focus();});
  return {dispose(){disposed=true;revision++;runtimeDefinitions.dispose();globals.dispose();opener.dispose();viewer?.dispose();for(const model of sources.values())model.dispose();dialog.remove();}};
}
